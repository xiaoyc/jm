﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LoggerGenerator
{
    class Program
    {
        static void Main(string[] args)
        {

            //var options = new ChromeOptions();
            //options.AddExtension(Path.GetFullPath("youdaogouwu-4.2.9.6.crx"));


            //using (IWebDriver _driver = new ChromeDriver(options))
            //{

            //    _driver.Navigate().GoToUrl("https://grafana-prod.mgmt.tv3cloud.net/dashboard/db/server-resources-overview-consolidated-by-component-linux?from=now-3h&to=now-10m&var-environment=mr_sim&var-component=All&var-host=azkvmacc003a.sim.mr.tv3cloud&var-host=azkvmacc005a.sim.mr.tv3cloud&var-host=azkvmacc007a.sim.mr.tv3cloud&var-host=azkvmacc008a.sim.mr.tv3cloud&var-host=azkvmacc009a.sim.mr.tv3cloud&var-host=azkvmamm001a.sim.mr.tv3cloud&var-host=azkvmamm002b.sim.mr.tv3cloud");
            //    string pageSource = _driver.PageSource;


            //}

            string url = "https://jira-fe-p01.mr.ericsson.se:8443/browse/MF-86551?filter=-4";

            //            GenerateSnapshot(url, "dash-row", @"E:\123\test.png");
            GenerateSnapshot(url, "body", @"E:\123\test.png");

        }

        public static void GenerateSnapshot(string url, string selector, string filePath)
        {
            using (IWebDriver driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)))
            {
                try
                {
                    driver.Manage().Window.Maximize();
                }
                catch (Exception ex) { }

                driver.Navigate().GoToUrl(url);

                WaitForAjax(driver);

                IWebElement remElement = WaitUntilGetElement(driver, By.CssSelector(selector));

                Point location = remElement.Location;

                IWebElement timeDropDownButton = WaitUntilGetElement(driver, By.ClassName("gf-timepicker-nav-btn"));
                new Actions(driver).MoveToElement(timeDropDownButton).Click().Perform();

                IWebElement starTimeElement = WaitUntilGetElement(driver, By.XPath("//input[@ng-model='ctrl.timeRaw.from']"));

                starTimeElement.Clear();
                starTimeElement.SendKeys("2017-12-10 11:13:47");

                IWebElement endTimeElement = WaitUntilGetElement(driver, By.XPath("//input[@ng-model='ctrl.timeRaw.to']"));
                endTimeElement.Clear();
                endTimeElement.SendKeys("2017-12-13 11:13:47");

                IWebElement applyButton = WaitUntilGetElement(driver, By.XPath("//button[@ng-click='ctrl.applyCustom();']"));

                new Actions(driver).MoveToElement(applyButton).Click().Perform();

                WaitForAjax(driver);

                //var screenshot = (driver as ChromeDriver).GetScreenshot();
                //using (MemoryStream stream = new MemoryStream(screenshot.AsByteArray))
                //{
                //    using (Bitmap bitmap = new Bitmap(stream))
                //    {
                //        RectangleF part = new RectangleF(location.X, location.Y, remElement.Size.Width, remElement.Size.Height);
                //        using (Bitmap bn = bitmap.Clone(part, bitmap.PixelFormat))
                //        {
                //            bn.Save(filePath, System.Drawing.Imaging.ImageFormat.Png);
                //        }
                //    }
                //}

                //var screenshot = GetEntereScreenshot(driver);
               // screenshot.Save(filePath);

                //var target = WaitUntilGetElement(driver, By.XPath("//dash-links-container/dash-link/div/a[@class='pointer gf-form-label']")).GetAttribute("href").ToString();

                //driver.Navigate().GoToUrl(target);

                //WaitForAjax(driver);



                driver.Close();
            }
        }

        //private IWebDriver _driver = new ChromeDriver(CHROME_DRIVER_PATH);
        //screenshot.SaveAsFile(saveFileName, ImageFormat.Jpeg);

        //public static Bitmap GetEntereScreenshot(IWebDriver driver)
        //{

        //    Bitmap stitchedImage = null;
        //    try
        //    {
        //        long totalwidth1 = (long)((IJavaScriptExecutor)driver).ExecuteScript("return document.body.offsetWidth");//documentElement.scrollWidth");

        //        long totalHeight1 = (long)((IJavaScriptExecutor)driver).ExecuteScript("return  document.body.parentNode.scrollHeight");

        //        int totalWidth = (int)totalwidth1;
        //        int totalHeight = (int)totalHeight1;

        //        // Get the Size of the Viewport
        //        long viewportWidth1 = (long)((IJavaScriptExecutor)driver).ExecuteScript("return document.body.clientWidth");//documentElement.scrollWidth");
        //        long viewportHeight1 = (long)((IJavaScriptExecutor)driver).ExecuteScript("return window.innerHeight");//documentElement.scrollWidth");

        //        int viewportWidth = (int)viewportWidth1;
        //        int viewportHeight = (int)viewportHeight1;


        //        // Split the Screen in multiple Rectangles
        //        List<Rectangle> rectangles = new List<Rectangle>();
        //        // Loop until the Total Height is reached
        //        for (int i = 0; i < totalHeight; i += viewportHeight)
        //        {
        //            int newHeight = viewportHeight;
        //            // Fix if the Height of the Element is too big
        //            if (i + viewportHeight > totalHeight)
        //            {
        //                newHeight = totalHeight - i;
        //            }
        //            // Loop until the Total Width is reached
        //            for (int ii = 0; ii < totalWidth; ii += viewportWidth)
        //            {
        //                int newWidth = viewportWidth;
        //                // Fix if the Width of the Element is too big
        //                if (ii + viewportWidth > totalWidth)
        //                {
        //                    newWidth = totalWidth - ii;
        //                }

        //                // Create and add the Rectangle
        //                Rectangle currRect = new Rectangle(ii, i, newWidth, newHeight);
        //                rectangles.Add(currRect);
        //            }
        //        }

        //        // Build the Image
        //        stitchedImage = new Bitmap(totalWidth, totalHeight);
        //        // Get all Screenshots and stitch them together
        //        Rectangle previous = Rectangle.Empty;
        //        foreach (var rectangle in rectangles)
        //        {
        //            // Calculate the Scrolling (if needed)
        //            if (previous != Rectangle.Empty)
        //            {
        //                int xDiff = rectangle.Right - previous.Right;
        //                int yDiff = rectangle.Bottom - previous.Bottom;
        //                // Scroll
        //                //selenium.RunScript(String.Format("window.scrollBy({0}, {1})", xDiff, yDiff));
        //                ((IJavaScriptExecutor)driver).ExecuteScript(String.Format("window.scrollBy({0}, {1})", xDiff, yDiff));
        //                System.Threading.Thread.Sleep(200);
        //            }

        //            // Take Screenshot
        //            var screenshot = ((ITakesScreenshot)driver).GetScreenshot();

        //            // Build an Image out of the Screenshot
        //            Image screenshotImage;
        //            using (MemoryStream memStream = new MemoryStream(screenshot.AsByteArray))
        //            {
        //                screenshotImage = Image.FromStream(memStream);
        //            }

        //            // Calculate the Source Rectangle
        //            Rectangle sourceRectangle = new Rectangle(viewportWidth - rectangle.Width, viewportHeight - rectangle.Height, rectangle.Width, rectangle.Height);

        //            // Copy the Image
        //            using (Graphics g = Graphics.FromImage(stitchedImage))
        //            {
        //                g.DrawImage(screenshotImage, rectangle, sourceRectangle, GraphicsUnit.Pixel);
        //            }

        //            // Set the Previous Rectangle
        //            previous = rectangle;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        // handle
        //    }
        //    return stitchedImage;
        //}

        public static IWebElement WaitUntilGetElement(IWebDriver driver, By by)
        {
            IWebElement remElement = null;

            do
            {
                try
                {
                    remElement = driver.FindElement(by);
                }
                catch (Exception ex)
                {
                    Thread.Sleep(200);
                }

            } while (remElement == null);


            //var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10000));
            //wait.Until<IWebElement>(d => { return d.FindElement(by);});

            return remElement;
        }

        public static void WaitForAjax(IWebDriver driver)
        {
            //    while (true) // Handle timeout somewhere
            //    {
            //        //string jqueryAjaxReadyScript = "return jQuery.active == 0";
            //        string angularReadyScript = "return angular.element(document).injector().get('$http').pendingRequests.length === 0";
            //        //var jsAjaxIsComplete = (bool)(driver as IJavaScriptExecutor).ExecuteScript("return document.readyState").ToString().Equals("complete");

            //        var angularComplete = (bool)(driver as IJavaScriptExecutor).ExecuteScript(angularReadyScript);
            //        if (angularComplete)
            //            break;
            //        Thread.Sleep(100);
            //    }



            var pageLoadWait = new WebDriverWait(driver, TimeSpan.FromSeconds(3000));
            pageLoadWait.Until<bool>(
                (d) =>
                {
                    return (bool)(d as IJavaScriptExecutor).ExecuteScript(
                                                                    @"
                                                                    try {
                                                                      if (document.readyState !== 'complete') {
                                                                        return false; // Page not loaded yet
                                                                      }
                                                                      if (window.jQuery) {
                                                                        if (window.jQuery.active) {
                                                                          return false;
                                                                        } else if (window.jQuery.ajax && window.jQuery.ajax.active) {
                                                                          return false;
                                                                        }
                                                                      }
                                                                      if (window.angular) {
                                                                        if (!window.qa) {
                                                                          // Used to track the render cycle finish after loading is complete
                                                                          window.qa = {
                                                                            doneRendering: false
                                                                          };
                                                                        }
                                                                        // Get the angular injector for this app (change element if necessary)
                                                                        var injector = window.angular.element('body').injector();
                                                                        // Store providers to use for these checks
                                                                        var $rootScope = injector.get('$rootScope');
                                                                        var $http = injector.get('$http');
                                                                        var $timeout = injector.get('$timeout');
                                                                        // Check if digest
                                                                        if ($rootScope.$$phase === '$apply' || $rootScope.$$phase === '$digest' || $http.pendingRequests.length !== 0) {
                                                                          window.qa.doneRendering = false;
                                                                          return false; // Angular digesting or loading data
                                                                        }
                                                                        if (!window.qa.doneRendering) {
                                                                          // Set timeout to mark angular rendering as finished
                                                                          $timeout(function() {
                                                                            window.qa.doneRendering = true;
                                                                          }, 0);
                                                                          return false;
                                                                        }
                                                                      }
                                                                      return true;
                                                                    } catch (ex) {
                                                                      return false;
                                                                    }");
                });
        }
    }
}
