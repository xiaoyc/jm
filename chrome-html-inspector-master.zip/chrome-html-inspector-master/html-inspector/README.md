# Chrome HTML Inspector

- [ ] Icon
- [ ] Theme(Solarized)
- [ ] Material Design
- [ ] Scroll to switch in parent&child
- [ ] Pinned on the page, Esc to close

## Usage

  1. Click icon to enable capture;
  1. Press Ctrl+Alt and move mouse cursor to the HTML element.
