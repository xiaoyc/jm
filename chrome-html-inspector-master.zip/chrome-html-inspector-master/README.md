# Chrome HTML Inspector

## Todo

- [ ] Icon
- [ ] Theme(Solarized)
- [ ] Material Design
- [ ] Scroll to switch in parent&child
- [ ] Click to copy to clipboard

## Usage

  1. Click icon to enable capture;
  1. Press Ctrl+Alt and then move your mouse to an element to show the inspect window;
  1. Press Esc to close the inspect window.
